package us.elopez.projecttwo;

public interface RegistrationCallback {
    void onSuccess();
    void onFailure(String message);
}
