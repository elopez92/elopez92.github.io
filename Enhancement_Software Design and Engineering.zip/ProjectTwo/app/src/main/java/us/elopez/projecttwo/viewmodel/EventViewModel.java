package us.elopez.projecttwo.viewmodel;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import java.util.List;

import us.elopez.projecttwo.AppDatabase;
import us.elopez.projecttwo.EventDao;
import us.elopez.projecttwo.data.model.EventEntity;

/**
 * ViewModel for managing event-related operations.
 */
public class EventViewModel extends ViewModel {
    private final EventDao eventDao;
    private final LiveData<List<EventEntity>> events;

    /**
     * Constructor that initializes the ViewModel with event data.
     *
     * @param eventDao  The eventDao.
     * @param username  The currently logged-in user's username.
     */
    public EventViewModel(EventDao eventDao, String username) {
        this.eventDao = eventDao;
        this.events = eventDao.getEventsForUser(username);
    }

    /**
     * Returns a LiveData list of events for the user.
     */
    public LiveData<List<EventEntity>> getEvents() {
        return events;
    }

    /**
     * Inserts an event into the database asynchronously.
     */
    public void insertEvent(EventEntity event) {
        AppDatabase.databaseWriteExecutor.execute(() -> eventDao.insertEvent(event));
    }

    /**
     * Deletes an event from the database asynchronously.
     */
    public void deleteEvent(EventEntity event) {
        AppDatabase.databaseWriteExecutor.execute(() -> eventDao.deleteEvent(event));
    }

    /**
     * Factory class for ViewModel instantiation.
     */
    public static class Factory implements ViewModelProvider.Factory {
        private final EventDao eventDao;
        private final String username;

        public Factory(EventDao dao, String user) {
            this.eventDao = dao;
            this.username = user;
        }

        @NonNull
        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new EventViewModel(eventDao, username);
        }
    }
}
