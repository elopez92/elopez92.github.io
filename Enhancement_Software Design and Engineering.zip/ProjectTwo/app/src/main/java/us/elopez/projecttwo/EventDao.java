package us.elopez.projecttwo;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import us.elopez.projecttwo.data.model.EventEntity;

@Dao
public interface EventDao {
    @Insert
    void insertEvent(EventEntity event);

    @Query("SELECT * FROM events WHERE username = :username")
    LiveData<List<EventEntity>> getEventsForUser(String username);

    @Delete
    void deleteEvent(EventEntity event);
}
