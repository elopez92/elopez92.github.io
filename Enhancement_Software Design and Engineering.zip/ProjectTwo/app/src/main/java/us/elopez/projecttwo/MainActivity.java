package us.elopez.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import us.elopez.projecttwo.data.model.EventEntity;
import us.elopez.projecttwo.viewmodel.EventViewModel;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_ADD_EVENT = 1;
    private RecyclerView recyclerView;
    private Button addEventButton;
    private AppDatabase db;
    String username;
    private EventAdapter eventAdapter;
    private SharedPreferences sharedPreferences;
    private EventViewModel eventViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        addEventButton = findViewById(R.id.addEventButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventAdapter = new EventAdapter();
        recyclerView.setAdapter(eventAdapter);

        // Get the logged-in user's username from SharedPreferences
        sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        username = sharedPreferences.getString("username", "");

        // Initialize database
        db = AppDatabase.getInstance(this);
        eventViewModel = new ViewModelProvider(this, new EventViewModel.Factory(db.eventDao(), username)).get(EventViewModel.class);

        eventViewModel.getEvents().observe(this, events -> {
            eventAdapter.setEvents(events);
        });

        // Set listener for adding a new event
        addEventButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, EventDetailsActivity.class);
            startActivity(intent);
        });

        eventAdapter.setOnItemClickListener(position -> {
            EventEntity event = eventAdapter.getEventAt(position);
            eventViewModel.deleteEvent(event);
            Toast.makeText(MainActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_signout) {
            signOut();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Logs out the user by clearing stored credentials and returning to the login screen.
     */
    private void signOut() {
        // Clear the saved username
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("username");
        editor.apply();

        // Navigate to the login activity and clear the activity stack
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }



    private void addEventToList(String name, String datetime) {
        EventEntity newEvent = new EventEntity(name, datetime);
        eventViewModel.insertEvent(newEvent);
    }
}