package us.elopez.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import us.elopez.projecttwo.data.model.EventEntity;
import us.elopez.projecttwo.viewmodel.EventViewModel;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_ADD_EVENT = 1;
    private RecyclerView recyclerView;
    private Button addEventButton;
    private EditText searchBar;
    private Spinner sortSpinner;
    private AppDatabase db;
    String username;
    private EventAdapter eventAdapter;
    private SharedPreferences sharedPreferences;
    private EventViewModel eventViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        addEventButton = findViewById(R.id.addEventButton);
        searchBar = findViewById(R.id.searchBar);
        sortSpinner = findViewById(R.id.sortSpinner);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventAdapter = new EventAdapter();
        recyclerView.setAdapter(eventAdapter);

        // Get the logged-in user's username from SharedPreferences
        sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        username = sharedPreferences.getString("username", "");

        // Initialize database
        db = AppDatabase.getInstance(this);
        eventViewModel = new ViewModelProvider(this, new EventViewModel.Factory(db.eventDao(), username)).get(EventViewModel.class);

        eventViewModel.getEvents().observe(this, events -> {
            eventAdapter.setEvents(events);
        });

        // Set listener for adding a new event
        addEventButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, EventDetailsActivity.class);
            startActivity(intent);
        });

        eventAdapter.setOnItemClickListener(position -> {
            EventEntity event = eventAdapter.getEventAt(position);
            eventViewModel.deleteEvent(event);
            eventAdapter.removeEventAt(position);
            Toast.makeText(MainActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
        });

        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                eventViewModel.setFilterQuery(s.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        // Sorting options
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                R.layout.spinner_item, new String[]{"Sort by Date", "Sort by Name"});
        adapter.setDropDownViewResource(R.layout.spinner_item);
        sortSpinner.setAdapter(adapter);

        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    eventViewModel.setSortType(EventViewModel.SortType.BY_DATE);
                } else {
                    eventViewModel.setSortType(EventViewModel.SortType.BY_NAME);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_signout) {
            signOut();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Logs out the user by clearing stored credentials and returning to the login screen.
     */
    private void signOut() {
        // Clear the saved username
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("username");
        editor.apply();

        // Navigate to the login activity and clear the activity stack
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

}